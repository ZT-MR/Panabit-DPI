#!/bin/sh

cgi_readcfg()
{
        local myline
        local mykey
        local myval
        local myprefix=$2

        while read myline; do
                # strip space at the string head
                myline="${myline#${myline%%[! ]*}}"

                # skip empty line
                [ -z "$myline" ] && continue

                # skip comment line
                [ "${myline%${myline#?}}" = "#" ] && continue

                mykey="${myline%%=*}"
                myval="${myline#*=}"
                if [ "${myval%${myval#?}}" = '"' ]; then
                        # strip first double quotes
                        myval="${myval#\"}"
                        # strip last double quotes
                        myval="${myval%\"}"
                fi
                read -r "${myprefix}${mykey}" <<EOF
${myval}
EOF
        done < $1
}

###. /etc/PG.conf
###. ${PGETC}/httpd.conf
cgi_readcfg /etc/PG.conf
cgi_readcfg ${PGETC}/httpd.conf

APIROOT="${dir}/cgi-bin"
LOGIN_DIR="/usr/ramdisk/weblogin"
USERDIR="/usr/ramdisk/etc/webuser"
WEBLOGIN="/usr/ramdisk/weblogin"
WEBACL="${PGETC}/web/webacl.conf"

FLOWEYE="/usr/ramdisk/bin/floweye"
ESCTOOL="/usr/ramdisk/bin/esctool"
AESTOOL="/usr/ramdisk/bin/aes_tool"
TRANDOM="/usr/ramdisk/bin/random_time"
URLDECODE="/usr/ramdisk/bin/urldecode"

cookie_make()
{
    random_src=`${TRANDOM}`
    random_str=`echo ${random_src} | awk -F":" '{print $3$2}'`
    enc_code=`${ESCTOOL} -e ${random_str}`
    
    echo "paonline_Panalog_$$_`date +%s`_${enc_code}-443-"
}

echo_query_error()
{
    printf "Content-type: text/html\r\n"
    printf "\r\n"
    
    cat << EOF
<html>
<head>
    <title>Query Error</title>
</head>
<body>
    <div style="width:200px; height:100px; margin: 100px auto; text-align: center;">
        <h1>Query Error</h1>
        <div>$1</div>
    </div>
</body>
</html>
EOF
    exit 0
}

# ������
[ ! -f ${WEBACL} ] && echo_query_error "sysconf not found"
sign_query_enable=`grep sign_query_enable= ${WEBACL} | awk -F= '{print $2}'`
sign_query_key=`grep sign_query_key= ${WEBACL} | awk -F= '{print $2}'`

[ "${sign_query_enable}" != "1" ] && echo_query_error "sign_query is disabled"
[ "${sign_query_key}" = "" ] && echo_query_error "sign_query_key not config"

[ "${CGI_sign_strs}" = "" ] && echo_query_error "sign_strs is empty"
[ "${CGI_sign_time}" = "" ] && echo_query_error "sign_time is empty"
[ "${CGI_route}" = "" ] && echo_query_error "route not found"

[ ${#CGI_sign_strs} -ne 32 ] && echo_query_error "sign_strs is invalid"
[ ${#CGI_sign_time} -ne 10 ] && echo_query_error "sign_time is invalid"

if ! echo "${CGI_sign_strs}" | grep -qE '^[a-z0-9]+$'; then
    echo_query_error "sign_strs is invalid"
fi

if ! echo "${CGI_sign_time}" | grep -qE '^[0-9]+$'; then
    echo_query_error "sign_time must contain only digits"
fi

current_time=`date +%s`
time_diff=$((current_time - ${CGI_sign_time}))
if [ "$time_diff" -lt 0 ]; then
    time_diff=$(( -time_diff ))
fi

if [ "$time_diff" -gt 300 ]; then
    echo_query_error "Panalog time is too old or too new (max allowed: 300 seconds)"
fi

src_strs=`${AESTOOL} -d ${sign_query_key} ${CGI_sign_strs}`
[ $? -ne 0 ] && echo_query_error "decrypting time"

[ "${src_strs}" != "NTM_${CGI_sign_time}" ] && echo_query_error "invalid sign_strs"

# ����Cookie
cookie=`cookie_make`
cookie_fname="$LOGIN_DIR/${cookie}"

mkdir -p ${LOGIN_DIR}
echo "ip=${REMOTE_ADDR}" > ${cookie_fname}
echo "user=$username" >> ${cookie_fname}
echo "login_level=1" >> ${cookie_fname}
echo "logintime=`date +%s`" >> ${cookie_fname}
echo "user=$username" >> ${cookie_fname}

# 302��ת
route=`${URLDECODE} ${CGI_route}`
printf "HTTP/1.1 302 Found\r\n"
printf "Location: %s\r\n" "${CGI_route}"
printf "Content-Type: text/html\r\n"
printf "Cache-Control: no-cache\r\n"
printf "Set-Cookie: %s=%s; Secure; Path=/; HttpOnly\r\n" "${PANABIT_CKNAME}" "${cookie}"
printf "\r\n" 

echo "<!DOCTYPE html><meta http-equiv="refresh" content="0;url=${CGI_route}"><h1>Redirecting...</h1></html>"
