#!/bin/sh

cgi_readcfg()
{
        local myline
        local mykey
        local myval
        local myprefix=$2

        while read myline; do
                # strip space at the string head
                myline="${myline#${myline%%[! ]*}}"

                # skip empty line
                [ -z "$myline" ] && continue

                # skip comment line
                [ "${myline%${myline#?}}" = "#" ] && continue

                mykey="${myline%%=*}"
                myval="${myline#*=}"
                if [ "${myval%${myval#?}}" = '"' ]; then
                        # strip first double quotes
                        myval="${myval#\"}"
                        # strip last double quotes
                        myval="${myval%\"}"
                fi
                read -r "${myprefix}${mykey}" <<EOF
${myval}
EOF
        done < $1
}

###. /etc/PG.conf
###. ${PGETC}/httpd.conf
cgi_readcfg /etc/PG.conf
cgi_readcfg ${PGETC}/httpd.conf


APIROOT="${dir}/cgi-bin"
USERDIR="/usr/ramdisk/etc/webuser"
WEBLOGIN="/usr/ramdisk/weblogin"

FLOWEYE="/usr/ramdisk/bin/floweye"
ESCTOOL="/usr/ramdisk/bin/esctool"


print_json_head()
{
	printf "Content-Type:application/json;charset=gb2312\r\n"
	printf "\r\n"
}


retjson()
{
	print_json_head
	
	if [ "${3}" = "" ]; then
		echo -n "{ \"code\": ${1}, \"msg\": \"${2}\", \"data\": \"\"}"
	else
		echo -n "{ \"code\": ${1}, \"msg\": \"${2}\", \"data\": ${3}}"
	fi

	exit 0
}


WEB_LOGGER()
{	
	# $1 User
	# $2 Action
	# $3 Message

	local logfile="${DATAPATH}/web_`date +%Y.%m.%d`.log"
	local curtime="`date +%Y.%m.%d/%H:%M:%S`"

	echo "${curtime} ${REMOTE_ADDR} $1 $2 $3" >> ${logfile}
	sync
	sync
}


cookie_make()
{
	logintime="`date +%s1`"
	code="`/usr/ramdisk/bin/ipe_mkcode`"
	esc_code="`${ESCTOOL} -e ${code}`"
	echo "paonline_${CGI_username}_$$_${logintime}_${esc_code}_${SERVER_PORT}"
}


api_login()
{
	[ "${CGI_username}" = "" ] && retjson 1 "�û�������Ϊ��"
	[ "${CGI_password}" = "" ] && retjson 1 "���벻��Ϊ��"
	
	aes_name="`${ESCTOOL} -e ${CGI_username}`"
	usr_file="${USERDIR}/${aes_name}"
	
	[ ! -f "${usr_file}" ] && retjson 1 "�û�������"
	
	. ${usr_file}
	aes_pswd="`${ESCTOOL} -e ${CGI_password}`"
	[ "${aes_pswd}" != "${password}" ] && retjson 1 "��֤ʧ�ܣ��˺��������"
	
	mkdir -p "${WEBLOGIN}"
	ckinfo="`cookie_make`"
	ckfile="${WEBLOGIN}/${ckinfo}"
	CGI_username="${CGI_username}@api"

	echo "ip=${REMOTE_ADDR}" > ${ckfile}
	echo "user=${CGI_username}" >> ${ckfile}
	echo "login_level=${level}" >> ${ckfile}
	echo "logintime=`date +%Y.%m.%d/%H:%M:%S`" >> ${ckfile}
	
	WEB_LOGGER  "${CGI_username}" "�û�API�ӿڵ�¼" "user=${CGI_username},ip=${REMOTE_ADDR}"
	retjson 0 "��¼�ɹ�" "\"${ckinfo}\""
}


api_proxy()
{
	[ "${CGI_api_token}" = "" ] && retjson 1 "TOKEN����Ϊ��"
	token_file="${WEBLOGIN}/${CGI_api_token}"
	[ "`dirname ${token_file}`" != "${WEBLOGIN}" ] && retjson 1 "�����TOKEN����"
	[ ! -f "${token_file}" ] && retjson 1 "APIδ��¼"
	
	[ "${CGI_api_route}" = "" ] && retjson 1 "�ӿ�·�ɲ���Ϊ��"
	
	api_path="`echo ${CGI_api_route} | cut -d '@' -f1`"
	api_file="ajax_`echo ${CGI_api_route} | cut -d '@' -f2`"

	[ ! -d "${APIROOT}/${api_path}" ] && retjson 1 "δ֪·��"
	[ ! -f "${APIROOT}/${api_path}/${api_file}" ] && retjson 1 "δ֪�ӿ�"

	_dirname="`dirname ${APIROOT}/${api_path}/${api_file}`"
	[ "${_dirname}" != "${APIROOT}/${api_path}" ] && retjson 1 "����Ľӿڷ���"
	
	# ˢ��Token
	touch ${token_file}

	# ִ��API
	cd ../cgi-bin/${api_path}

	username=`echo ${CGI_api_token} | cut -d"_" -f2`
	export CGI_action="${CGI_api_action}"
	export PANABIT_USER="${username}@api"
	
	sh ${api_file}
}


case "${CGI_api_action}" in
	"api_login")
		api_login
		;;
		
	*)
		api_proxy
		;;
esac
