#!/bin/sh

. ../cgi-bin/common/ajax_common

sync_conf="${PGETC}/web/config_sync.conf"
esctool="/usr/ramdisk/bin/esctool"


retmsg()
{
	local ctx="${1}"
	local ctx_len=`echo -n "${ctx}" | wc -c`

	printf "Content-Type:text/plain\r\n"
	printf "Content-Length: ${ctx_len}\r\n"
	printf "\r\n"

	printf "${ctx}"
	exit 0
}

. ${sync_conf}

[ "${CGI_key}" = "" ] && retmsg "INV_KEY"

obj_key=`${esctool} -d "${CGI_key}"`
export PANABIT_USER="_sys_self_"

[ "${CGI_action}" != "config_sync" ] && retmsg "UNKNOW_ACTION"
[ "${obj_key}"    != "${key}" ] && retmsg "INV_KEY"

invcmd=`echo ${CGI_cmd} | grep "^floweye "`
[ "${invcmd}" = "" ] && retmsg "INV_CMD"

errmsg=`${CGI_cmd}`

if [ $? -ne 0 ]; then
	WEB_LOGGER "ִ������ͬ��[ʧ��]" "${CGI_cmd}"
	retmsg "ִ��ʧ��:${errmsg}"
else
	WEB_LOGGER "ִ������ͬ��[�ɹ�]" "${CGI_cmd}"
	retmsg
fi
