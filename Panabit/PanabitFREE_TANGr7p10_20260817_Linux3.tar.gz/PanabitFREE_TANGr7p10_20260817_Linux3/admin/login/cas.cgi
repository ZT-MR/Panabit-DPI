#!/bin/sh

. ../cgi-bin/common/ajax_common

CAS_AUTH_CONF="${PGETC}/web/cas_auth.conf"


print_xml_head()
{
	local charset=$1

	[ "${charset}" = "" ] && charset="utf-8"

	printf "Cache-Control:max-age=1\r\n"
	printf "X-Content-Type-Options:nosniff\r\n"
	printf "X-Frame-Options:SAMEORIGIN\r\n"
	printf "X-Xss-Protection:1;mode=block\r\n"
	printf "Referrer-Policy: strict-origin-when-cross-origin\r\n"
	printf "Content-Security-Policy:upgrade-insecure-requests\r\n"
	printf "Content-Security-Policy:'default-src' 'self' 'unsafe-eval';\r\n"
	printf "Content-Type:application/xml;charset=${charset}\r\n"
	printf "\r\n"
}


xml_extract_value()
{
	local xml="$1"
	local tag="$2"

	echo "$xml" | sed -n "s/.*<${tag}>\([^<]*\)<\/${tag}>.*/\1/p" | head -1
}


validate_ticket()
{
	local ticket="$1"

	[ -z "${ticket}" ] && return 1

	len=`echo "${ticket}" | wc -c`
	if [ ${len} -lt 10 ] || [ ${len} -gt 200 ]; then
		return 1
	fi

	echo "${ticket}" | grep -E '^[a-zA-Z0-9\-]+$' > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		return 1
	fi

	return 0
}

if [ -z "${CGI_ticket}" ]; then
	retjson 1 "No Ticket"
fi

if ! validate_ticket "${CGI_ticket}"; then
	retjson 1 "Invalid Ticket Format"
fi

# ��������ļ�
if [ ! -f "${CAS_AUTH_CONF}" ]; then
	retjson 1 "CAS Config Not Found"
fi

. ${CAS_AUTH_CONF}

if [ "${cas_auth}" != "1" ]; then
	retjson 1 "CAS Auth Disabled"
fi

if [ -z "${cas_user_url}" ]; then
	retjson 1 "CAS User URL Not Configured"
fi

# ����CAS, ��ȡ�û���Ϣ
SERVICE=`${URLENCODE} -e "https://${HTTP_HOST}/login/cas.cgi"`
CAS_URL="${cas_user_url}?service=${SERVICE}&ticket=${CGI_ticket}"
XML_RESPONSE=`${CURL} -s -k "${CAS_URL}" 2>/dev/null`

if [ $? -ne 0 ] || [ -z "${XML_RESPONSE}" ]; then
	retjson 1 "CAS Request Failed"
fi

# ����XML��ȡ�û���
USERNAME=`xml_extract_value "${XML_RESPONSE}" "cas:user"`

if [ -z "${USERNAME}" ]; then
	USERNAME=`xml_extract_value "${XML_RESPONSE}" "user"`
fi

if [ -z "${USERNAME}" ]; then
	print_xml_head
	echo "${XML_RESPONSE}"
	exit 0
fi

export CGI_action="cas_login"
export CGI_cas_level="${cas_level}"
export CGI_pakey=`${FLOWEYE} cloud config getkey=1`
export CGI_username=`${FLOWEYE} iconv utf8togb2312 "${USERNAME}"`

/usr/ramdisk/admin/login/user.cgi
