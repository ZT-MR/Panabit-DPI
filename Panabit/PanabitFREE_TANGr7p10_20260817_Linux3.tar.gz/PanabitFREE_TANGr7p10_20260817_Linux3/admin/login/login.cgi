#!/bin/sh

WWW="/usr/ramdisk/admin"
TPL_DIR="${WWW}/html/common/"


case "${CGI_f}" in
    "css")
        ctx="text/css"
        req="${TPL_DIR}/login.css"
        ;;

    "js")
        ctx="application/x-javascript"
        req="${TPL_DIR}/login.js"
        ;;

    "favicon")
        ctx="image/png"
        req="${WWW}/favicon.png"
        ;;

    "palogo")
        ctx="image/png"
        req="${WWW}/img/logo.png"
        ;;

    "cmcclogo")
        ctx="image/png"
        req="${WWW}/img/cmcc.png"
        ;;

    "crypto")
        ctx="application/x-javascript"
        req="${WWW}/img/crypto.js"
        ;;

    *)
        ctx="text/html"
        req="${TPL_DIR}/login.html"
        ;;
esac

printf "Content-type: ${ctx}\r\n"
printf "Cache-Control:max-age=1\r\n"
printf "X-Content-Type-Options:nosniff\r\n"
printf "X-Frame-Options:SAMEORIGIN\r\n"
printf "X-Xss-Protection:1;mode=block\r\n"
printf "Referrer-Policy: strict-origin-when-cross-origin\r\n"
printf "Content-Security-Policy:default-src 'self' 'unsafe-eval'\r\n"
printf "\r\n"

[ -f ${req} ] && cat "${req}"
