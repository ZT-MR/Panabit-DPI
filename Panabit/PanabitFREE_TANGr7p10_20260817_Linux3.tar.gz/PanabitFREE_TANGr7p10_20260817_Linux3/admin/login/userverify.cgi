#!/bin/sh

export CGI_username="cloud"
export CGI_action="cloud_login"
export CGI_pakey="${CGI_pakey}"

/usr/ramdisk/admin/login/user.cgi
